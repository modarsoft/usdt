from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import logging

# إنشاء Base
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(String(50), unique=True, nullable=False)
    username = Column(String(100))
    first_name = Column(String(100))
    last_name = Column(String(100))
    phone = Column(String(20))
    balance_usdt = Column(Float, default=0.0)
    balance_fiat = Column(Float, default=0.0)
    total_trades = Column(Integer, default=0)
    rating = Column(Float, default=5.0)
    is_banned = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    language = Column(String(10), default='ar')
    verification_status = Column(String(20), default='pending')

class Offer(Base):
    __tablename__ = 'offers'
    
    id = Column(Integer, primary_key=True)
    offer_id = Column(String(50), unique=True, nullable=False)
    user_id = Column(String(50), nullable=False)
    offer_type = Column(String(10), nullable=False)  # buy, sell
    amount_usdt = Column(Float, nullable=False)
    price_per_usdt = Column(Float, nullable=False)
    total_amount = Column(Float, nullable=False)
    payment_method = Column(String(50), nullable=False)
    commission = Column(Float, default=0.0)
    status = Column(String(20), default='active')  # active, completed, cancelled, expired
    is_highlighted = Column(Boolean, default=False)
    is_crossed = Column(Boolean, default=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Trade(Base):
    __tablename__ = 'trades'
    
    id = Column(Integer, primary_key=True)
    trade_id = Column(String(50), unique=True, nullable=False)
    buyer_id = Column(String(50), nullable=False)
    seller_id = Column(String(50), nullable=False)
    offer_id = Column(String(50), nullable=False)
    amount_usdt = Column(Float, nullable=False)
    price_per_usdt = Column(Float, nullable=False)
    total_amount = Column(Float, nullable=False)
    commission = Column(Float, default=0.0)
    status = Column(String(20), default='pending')  # pending, completed, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

class CommissionSetting(Base):
    __tablename__ = 'commission_settings'
    
    id = Column(Integer, primary_key=True)
    commission_type = Column(String(50), nullable=False)  # buy, sell, both
    percentage = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)
    created_by = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AdminMessage(Base):
    __tablename__ = 'admin_messages'
    
    id = Column(Integer, primary_key=True)
    message_type = Column(String(50), unique=True, nullable=False)  # welcome, help, rules
    content_ar = Column(Text, nullable=False)
    content_en = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Admin(Base):
    __tablename__ = 'admins'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(String(50), unique=True, nullable=False)
    username = Column(String(100))
    permissions = Column(Text)  # JSON string for permissions
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Transaction(Base):
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    transaction_id = Column(String(50), unique=True, nullable=False)
    user_id = Column(String(50), nullable=False)
    type = Column(String(20), nullable=False)  # deposit, withdrawal, trade
    amount = Column(Float, nullable=False)
    currency = Column(String(10), nullable=False)  # USDT, fiat
    status = Column(String(20), default='pending')  # pending, completed, failed
    details = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

class DatabaseManager:
    def __init__(self, database_url):
        self.engine = create_engine(database_url)
        self.create_tables()
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
        self.initialize_default_data()
    
    def create_tables(self):
        """إنشاء الجداول في قاعدة البيانات"""
        try:
            Base.metadata.create_all(self.engine)
            logging.info("✅ تم إنشاء الجداول بنجاح")
        except Exception as e:
            logging.error(f"❌ خطأ في إنشاء الجداول: {e}")
            raise
    
    def initialize_default_data(self):
        """تهيئة البيانات الافتراضية"""
        try:
            # إضافة رسائل افتراضية إذا لم تكن موجودة
            default_messages = [
                ('welcome', 
                 '🎉 **مرحباً بك في بوت تداول USDT!**\n\n'
                 'منصة آمنة وسهلة لشراء وبيع USDT\n'
                 'اختر من القائمة أدناه لبدء التداول',
                 '🎉 **Welcome to USDT Trading Bot!**\n\n'
                 'Secure and easy platform for buying and selling USDT\n'
                 'Choose from the menu below to start trading'),
                
                ('help',
                 'ℹ️ **مركز المساعدة**\n\n'
                 '🛒 **لشراء USDT:**\n'
                 '1. اختر "عروض الشراء"\n'
                 '2. اختر العرض المناسب\n'
                 '3. تواصل مع البائع\n\n'
                 '💰 **لبيع USDT:**\n'
                 '1. اختر "عروض البيع"\n'
                 '2. اختر العرض المناسب\n'
                 '3. تواصل مع المشتري\n\n'
                 '➕ **لإنشاء عرض:**\n'
                 '1. اختر "إنشاء عرض"\n'
                 '2. اختر النوع (شراء/بيع)\n'
                 '3. اتبع التعليمات\n\n'
                 '💬 للأسئلة والدعم: @support',
                 'ℹ️ **Help Center**\n\n'
                 '🛒 **To buy USDT:**\n'
                 '1. Choose "Buy Offers"\n'
                 '2. Select suitable offer\n'
                 '3. Contact the seller\n\n'
                 '💰 **To sell USDT:**\n'
                 '1. Choose "Sell Offers"\n'
                 '2. Select suitable offer\n'
                 '3. Contact the buyer\n\n'
                 '➕ **To create offer:**\n'
                 '1. Choose "Create Offer"\n'
                 '2. Select type (buy/sell)\n'
                 '3. Follow instructions\n\n'
                 '💬 For questions and support: @support'),
                
                ('rules',
                 '📋 **قوانين الاستخدام**\n\n'
                 '1. الالتزام بالأخلاقيات في التعامل\n'
                 '2. عدم نشر عروض وهمية\n'
                 '3. احترام أوقات الآخرين\n'
                 '4. الالتزام بالأسعار المعلنة\n'
                 '5. عدم الاحتيال أو الغش\n'
                 '6. الحفاظ على خصوصية البيانات',
                 '📋 **Usage Rules**\n\n'
                 '1. Adhere to ethics in dealing\n'
                 '2. Do not post fake offers\n'
                 '3. Respect others\' time\n'
                 '4. Adhere to announced prices\n'
                 '5. No fraud or cheating\n'
                 '6. Maintain data privacy')
            ]
            
            for msg_type, content_ar, content_en in default_messages:
                if not self.session.query(AdminMessage).filter_by(message_type=msg_type).first():
                    message = AdminMessage(
                        message_type=msg_type,
                        content_ar=content_ar,
                        content_en=content_en
                    )
                    self.session.add(message)
            
            # إضافة إعدادات العمولة الافتراضية
            commission_types = [
                ('buy', 1.0, '0'),
                ('sell', 1.0, '0'),
                ('both', 0.5, '0')
            ]
            
            for comm_type, percentage, created_by in commission_types:
                if not self.session.query(CommissionSetting).filter_by(commission_type=comm_type).first():
                    setting = CommissionSetting(
                        commission_type=comm_type,
                        percentage=percentage,
                        created_by=created_by
                    )
                    self.session.add(setting)
            
            self.session.commit()
            logging.info("✅ تم تهيئة البيانات الافتراضية بنجاح")
            
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تهيئة البيانات الافتراضية: {e}")
    
    def get_user(self, telegram_id):
        """الحصول على مستخدم بواسطة معرف التيليقرام"""
        try:
            return self.session.query(User).filter_by(telegram_id=str(telegram_id)).first()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على المستخدم: {e}")
            return None
    
    def create_user(self, user_data):
        """إنشاء مستخدم جديد"""
        try:
            user = User(
                telegram_id=str(user_data['telegram_id']),
                username=user_data.get('username'),
                first_name=user_data.get('first_name'),
                last_name=user_data.get('last_name'),
                phone=user_data.get('phone')
            )
            self.session.add(user)
            self.session.commit()
            logging.info(f"✅ تم إنشاء مستخدم جديد: {user_data['telegram_id']}")
            return user
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في إنشاء المستخدم: {e}")
            return None
    
    def update_user(self, telegram_id, update_data):
        """تحديث بيانات المستخدم"""
        try:
            user = self.get_user(telegram_id)
            if user:
                for key, value in update_data.items():
                    if hasattr(user, key):
                        setattr(user, key, value)
                user.updated_at = datetime.utcnow()
                self.session.commit()
                return user
            return None
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تحديث المستخدم: {e}")
            return None
    
    def create_offer(self, offer_data):
        """إنشاء عرض جديد"""
        try:
            offer = Offer(
                offer_id=offer_data['offer_id'],
                user_id=str(offer_data['user_id']),
                offer_type=offer_data['offer_type'],
                amount_usdt=offer_data['amount_usdt'],
                price_per_usdt=offer_data['price_per_usdt'],
                total_amount=offer_data['total_amount'],
                payment_method=offer_data['payment_method'],
                description=offer_data.get('description', ''),
                commission=offer_data.get('commission', 0.0)
            )
            self.session.add(offer)
            self.session.commit()
            logging.info(f"✅ تم إنشاء عرض جديد: {offer_data['offer_id']}")
            return offer
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في إنشاء العرض: {e}")
            return None
    
    def get_active_offers(self, offer_type=None, payment_method=None):
        """الحصول على العروض النشطة"""
        try:
            query = self.session.query(Offer).filter_by(status='active')
            
            if offer_type:
                query = query.filter_by(offer_type=offer_type)
            if payment_method:
                query = query.filter_by(payment_method=payment_method)
            
            return query.order_by(Offer.created_at.desc()).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على العروض: {e}")
            return []
    
    def get_user_offers(self, telegram_id):
        """الحصول على عروض مستخدم معين"""
        try:
            return self.session.query(Offer).filter_by(
                user_id=str(telegram_id)
            ).order_by(Offer.created_at.desc()).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على عروض المستخدم: {e}")
            return []
    
    def toggle_offer_crossed(self, offer_id):
        """تبديل حالة تعطيل العرض"""
        try:
            offer = self.session.query(Offer).filter_by(offer_id=offer_id).first()
            if offer:
                offer.is_crossed = not offer.is_crossed
                offer.updated_at = datetime.utcnow()
                self.session.commit()
                return offer
            return None
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تبديل حالة العرض: {e}")
            return None
    
    def cancel_offer(self, offer_id):
        """إلغاء العرض"""
        try:
            offer = self.session.query(Offer).filter_by(offer_id=offer_id).first()
            if offer:
                offer.status = 'cancelled'
                offer.updated_at = datetime.utcnow()
                self.session.commit()
                return offer
            return None
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في إلغاء العرض: {e}")
            return None
    
    def get_commission_settings(self):
        """الحصول على إعدادات العمولة"""
        try:
            return self.session.query(CommissionSetting).filter_by(is_active=True).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على إعدادات العمولة: {e}")
            return []
    
    def update_commission(self, commission_type, percentage, admin_id):
        """تحديث إعدادات العمولة"""
        try:
            setting = self.session.query(CommissionSetting).filter_by(commission_type=commission_type).first()
            if not setting:
                setting = CommissionSetting(
                    commission_type=commission_type,
                    percentage=percentage,
                    created_by=str(admin_id)
                )
                self.session.add(setting)
            else:
                setting.percentage = percentage
                setting.created_by = str(admin_id)
            
            self.session.commit()
            return setting
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تحديث العمولة: {e}")
            return None
    
    def get_admin_message(self, message_type):
        """الحصول على رسالة إدارية"""
        try:
            return self.session.query(AdminMessage).filter_by(
                message_type=message_type, 
                is_active=True
            ).first()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على الرسالة: {e}")
            return None
    
    def update_admin_message(self, message_type, content_ar, content_en=None):
        """تحديث رسالة إدارية"""
        try:
            message = self.session.query(AdminMessage).filter_by(message_type=message_type).first()
            if not message:
                message = AdminMessage(
                    message_type=message_type,
                    content_ar=content_ar,
                    content_en=content_en
                )
                self.session.add(message)
            else:
                message.content_ar = content_ar
                if content_en:
                    message.content_en = content_en
                message.updated_at = datetime.utcnow()
            
            self.session.commit()
            return message
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تحديث الرسالة: {e}")
            return None
    
    def get_all_users(self):
        """الحصول على جميع المستخدمين"""
        try:
            return self.session.query(User).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على المستخدمين: {e}")
            return []
    
    def get_all_offers(self):
        """الحصول على جميع العروض"""
        try:
            return self.session.query(Offer).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على العروض: {e}")
            return []
    
    def get_all_trades(self):
        """الحصول على جميع الصفقات"""
        try:
            return self.session.query(Trade).all()
        except Exception as e:
            logging.error(f"❌ خطأ في الحصول على الصفقات: {e}")
            return []
    
    def create_trade(self, trade_data):
        """إنشاء صفقة جديدة"""
        try:
            trade = Trade(
                trade_id=trade_data['trade_id'],
                buyer_id=str(trade_data['buyer_id']),
                seller_id=str(trade_data['seller_id']),
                offer_id=trade_data['offer_id'],
                amount_usdt=trade_data['amount_usdt'],
                price_per_usdt=trade_data['price_per_usdt'],
                total_amount=trade_data['total_amount'],
                commission=trade_data.get('commission', 0.0)
            )
            self.session.add(trade)
            self.session.commit()
            return trade
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في إنشاء الصفقة: {e}")
            return None
    
    def update_trade_status(self, trade_id, status):
        """تحديث حالة الصفقة"""
        try:
            trade = self.session.query(Trade).filter_by(trade_id=trade_id).first()
            if trade:
                trade.status = status
                if status == 'completed':
                    trade.completed_at = datetime.utcnow()
                self.session.commit()
                return trade
            return None
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في تحديث حالة الصفقة: {e}")
            return None
    
    def close(self):
        """إغلاق الاتصال بقاعدة البيانات"""
        self.session.close()