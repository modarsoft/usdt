          '1. Adhere to ethics in dealing\n'
                 '2. Do not post fake offers\n'
                 '3. Respect others\' time\n'
                 '4. Adhere to announced prices\n'
                 '5. No fraud or cheating\n'
                 '6. Maintain data privacy')
            ]
            
            for msg_type, content_ar, content_en in default_messages:
                if not self.session.query(AdminMessage).filter_by(message_type=msg_type).first():
                    message = AdminMessage(
                        message_type=msg_type,
                        content_ar=content_ar,
                        content_en=content_en
                    )
                    self.session.add(message)
            
            # إضافة إعدادات العمولة الافتراضية
            commission_types = [
                ('buy', 1.0, '0'),
                ('sell', 1.0, '0'),
                ('both', 0.5, '0')
            ]
            
            for comm_type, perc