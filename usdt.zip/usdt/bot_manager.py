import asyncio
import logging
from telegram.ext import Application, Defaults
from telegram import Update
from telegram.ext import ContextTypes
import time
import threading
from datetime import datetime

class BotManager:
    def __init__(self, token, db_manager):
        self.token = token
        self.db = db_manager
        self.application = None
        self.last_activity = time.time()
        self.is_running = False
        
    async def initialize_bot(self):
        """تهيئة البوت مع إعدادات محسنة"""
        try:
            # إعدادات افتراضية للغة العربية
            defaults = Defaults(parse_mode='HTML', block=False)
            
            self.application = (
                Application.builder()
                .token(self.token)
                .defaults(defaults)
                .concurrent_updates(True)  # تفعيل التحديثات المتزامنة
                .pool_timeout(30)  # زيادة وقت الانتظار
                .connect_timeout(30)  # زيادة وقت الاتصال
                .read_timeout(30)  # زيادة وقت القراءة
                .build()
            )
            
            await self.setup_handlers()
            self.is_running = True
            logging.info("✅ البوت تم تهيئته بنجاح")
            return True
            
        except Exception as e:
            logging.error(f"❌ خطأ في تهيئة البوت: {e}")
            return False
    
    async def setup_handlers(self):
        """إعداد ال handlers مع معالجة الأخطاء"""
        from telegram.ext import CommandHandler, CallbackQueryHandler, MessageHandler, filters
        
        # إضافة handlers مع معالجة الأخطاء
        handlers = [
            CommandHandler("start", self.wrapped_start, block=False),
            CommandHandler("menu", self.wrapped_menu, block=False),
            CommandHandler("offers", self.wrapped_offers, block=False),
            CommandHandler("balance", self.wrapped_balance, block=False),
            CommandHandler("admin", self.wrapped_admin, block=False),
            CallbackQueryHandler(self.wrapped_callback, pattern=None, block=False),
        ]
        
        for handler in handlers:
            self.application.add_handler(handler)
        
        # إضافة معالج للأخطاء
        self.application.add_error_handler(self.error_handler)
    
    async def wrapped_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دالة start مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            from main import USDTradingBot
            bot = USDTradingBot()
            await bot.start(update, context)
        except Exception as e:
            await self.send_error_message(update, e, "start")
    
    async def wrapped_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دالة menu مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            from main import USDTradingBot
            bot = USDTradingBot()
            await bot.show_main_menu(update, context)
        except Exception as e:
            await self.send_error_message(update, e, "menu")
    
    async def wrapped_offers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دالة offers مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            from main import USDTradingBot
            bot = USDTradingBot()
            await bot.show_offers(update, context)
        except Exception as e:
            await self.send_error_message(update, e, "offers")
    
    async def wrapped_balance(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دالة balance مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            from main import USDTradingBot
            bot = USDTradingBot()
            await bot.show_balance(update, context)
        except Exception as e:
            await self.send_error_message(update, e, "balance")
    
    async def wrapped_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """دالة admin مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            from admin_panel import AdminPanel
            admin_panel = AdminPanel(self.db, self.config)
            await admin_panel.admin_dashboard(update, context)
        except Exception as e:
            await self.send_error_message(update, e, "admin")
    
    async def wrapped_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة CallbackQuery مع معالجة الأخطاء"""
        try:
            await self.update_activity()
            query = update.callback_query
            await query.answer()  # الرد الفوري على callback
            
            from main import USDTradingBot
            bot = USDTradingBot()
            await bot.button_handler(update, context)
            
        except Exception as e:
            await self.send_error_message(update, e, "callback")
    
    async def update_activity(self):
        """تحديث وقت النشاط الأخير"""
        self.last_activity = time.time()
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج الأخطاء العام"""
        try:
            logging.error(f"⚠️ خطأ في البوت: {context.error}")
            
            # إرسال رسالة خطأ للمستخدم
            if update and update.effective_chat:
                error_message = (
                    "⚠️ حدث خطأ غير متوقع\n\n"
                    "الرجاء المحاولة مرة أخرى أو استخدام الأمر /menu"
                )
                await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text=error_message
                )
        except Exception as e:
            logging.error(f"❌ خطأ في معالج الأخطاء: {e}")
    
    async def send_error_message(self, update: Update, error: Exception, command_name: str):
        """إرسال رسالة خطأ للمستخدم"""
        try:
            logging.error(f"❌ خطأ في الأمر {command_name}: {error}")
            
            error_message = (
                "⚠️ عذراً، حدث خطأ في معالجة طلبك\n\n"
                "الرجاء المحاولة مرة أخرى بعد قليل\n"
                "إذا استمرت المشكلة، اتصل بالدعم"
            )
            
            if update.message:
                await update.message.reply_text(error_message)
            elif update.callback_query:
                await update.callback_query.message.reply_text(error_message)
                
        except Exception as e:
            logging.error(f"❌ فشل إرسال رسالة الخطأ: {e}")
    
    async def health_check(self):
        """فحص صحة البوت بشكل دوري"""
        while self.is_running:
            try:
                current_time = time.time()
                inactivity_time = current_time - self.last_activity
                
                # إذا كان البوت خاملاً لأكثر من 10 دقائق، إعادة التشغيل
                if inactivity_time > 600:  # 10 دقائق
                    logging.info("🔄 إعادة تشغيل البوت بسبب الخمول")
                    await self.restart_bot()
                
                await asyncio.sleep(60)  # فحص كل دقيقة
                
            except Exception as e:
                logging.error(f"❌ خطأ في health check: {e}")
                await asyncio.sleep(60)
    
    async def restart_bot(self):
        """إعادة تشغيل البوت"""
        try:
            logging.info("🔄 إعادة تشغيل البوت...")
            self.is_running = False
            
            if self.application:
                await self.application.stop()
                await self.application.shutdown()
            
            await asyncio.sleep(5)
            await self.initialize_bot()
            await self.application.start()
            await self.application.updater.start_polling()
            
            logging.info("✅ البوت أعيد تشغيله بنجاح")
            
        except Exception as e:
            logging.error(f"❌ فشل إعادة تشغيل البوت: {e}")
    
    async def start_bot(self):
        """بدء تشغيل البوت"""
        try:
            if await self.initialize_bot():
                await self.application.initialize()
                await self.application.start()
                await self.application.updater.start_polling(
                    drop_pending_updates=True,  # تجاهل التحديثات المعلقة
                    allowed_updates=['message', 'callback_query', 'chat_member']
                )
                
                # بدء مراقبة الصحة
                asyncio.create_task(self.health_check())
                
                logging.info("🚀 البوت يعمل الآن")
                return True
            return False
            
        except Exception as e:
            logging.error(f"❌ فشل بدء البوت: {e}")
            return False