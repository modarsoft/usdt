import asyncio
import logging
import subprocess
import sys
import time
from datetime import datetime

class BotMonitor:
    def __init__(self):
        self.bot_process = None
        self.restart_count = 0
        self.max_restarts = 10
        
    def start_bot(self):
        """بدء تشغيل البوت"""
        try:
            logging.info("🚀 بدء تشغيل البوت...")
            self.bot_process = subprocess.Popen([
                sys.executable, "main.py"
            ])
            self.restart_count += 1
            return True
            
        except Exception as e:
            logging.error(f"❌ فشل بدء البوت: {e}")
            return False
    
    def stop_bot(self):
        """إيقاف البوت"""
        if self.bot_process:
            self.bot_process.terminate()
            self.bot_process.wait()
            logging.info("⏹️ تم إيقاف البوت")
    
    def is_bot_running(self):
        """التحقق من حالة البوت"""
        return self.bot_process and self.bot_process.poll() is None
    
    def monitor_loop(self):
        """حلقة المراقبة الرئيسية"""
        logging.info("👀 بدء مراقبة البوت...")
        
        while self.restart_count <= self.max_restarts:
            if not self.is_bot_running():
                logging.warning("⚠️ البوت متوقف، إعادة التشغيل...")
                self.stop_bot()
                
                if self.start_bot():
                    logging.info(f"✅ البوت أعيد تشغيله ({self.restart_count}/{self.max_restarts})")
                else:
                    logging.error("❌ فشل إعادة تشغيل البوت")
            
            time.sleep(30)  # التحقق كل 30 ثانية
        
        logging.error("🛑 تم الوصول إلى الحد الأقصى لإعادة التشغيل")
    
    def run(self):
        """تشغيل المراقب"""
        try:
            # بدء البوت لأول مرة
            if not self.start_bot():
                return
            
            # بدء المراقبة
            self.monitor_loop()
            
        except KeyboardInterrupt:
            logging.info("⏹️ إيقاف المراقب...")
            self.stop_bot()
        except Exception as e:
            logging.error(f"❌ خطأ في المراقب: {e}")
            self.stop_bot()

if __name__ == "__main__":
    # إعداد اللوجر
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('monitor.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    monitor = BotMonitor()
    monitor.run()