import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from database import DatabaseManager, User
from config import Config
import re

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

class SimpleUSDTBot:
    def __init__(self):
        self.config = Config()
        self.db = DatabaseManager(self.config.DATABASE_URL)
        self.application = None

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """بدء البوت بشكل مبسط"""
        user = update.effective_user
        
        # التحقق من وجود المستخدم
        db_user = self.db.get_user(user.id)
        
        if not db_user:
            # إنشاء مستخدم جديد
            user_data = {
                'telegram_id': str(user.id),
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name
            }
            db_user = self.db.create_user(user_data)
            logging.info(f"✅ تم إنشاء مستخدم جديد: {user.id}")
        
        if not db_user.phone:
            # إذا لم يكمل التسجيل، نطلب البيانات مباشرة
            await self.request_registration(update, context)
        else:
            # إذا كان مسجلاً، نعرض القائمة
            await self.show_main_menu(update, context)

    async def request_registration(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """طلب التسجيل بشكل مباشر"""
        keyboard = [
            [KeyboardButton("📱 مشاركة رقم الهاتف", request_contact=True)],
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
        
        await update.message.reply_text(
            "📝 مرحباً! لتتمكن من استخدام البوت، نحتاج إلى رقم هاتفك\n\n"
            "الرجاء استخدام زر 'مشاركة رقم الهاتف' أدناه:",
            reply_markup=reply_markup
        )

    async def handle_contact(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة رقم الهاتف"""
        if update.message.contact:
            phone_number = update.message.contact.phone_number
            user_id = update.effective_user.id
            
            # تحديث رقم الهاتف في قاعدة البيانات
            user = self.db.get_user(user_id)
            if user:
                user.phone = phone_number
                self.db.session.commit()
                
                # إزالة لوحة المفاتيح
                from telegram import ReplyKeyboardRemove
                await update.message.reply_text(
                    f"✅ تم تسجيل رقم هاتفك بنجاح!\n\n"
                    f"📱 الرقم: {phone_number}\n\n"
                    "يمكنك الآن استخدام البوت",
                    reply_markup=ReplyKeyboardRemove()
                )
                
                await self.show_main_menu(update, context)
        else:
            await update.message.reply_text("❌ لم يتم استلام رقم الهاتف. حاول مرة أخرى.")

    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض القائمة الرئيسية"""
        keyboard = [
            [InlineKeyboardButton("🛒 شراء USDT", callback_data="buy")],
            [InlineKeyboardButton("💰 بيع USDT", callback_data="sell")],
            [InlineKeyboardButton("👛 رصيدي", callback_data="balance")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.message:
            await update.message.reply_text("🏠 القائمة الرئيسية:", reply_markup=reply_markup)
        else:
            await update.callback_query.edit_message_text("🏠 القائمة الرئيسية:", reply_markup=reply_markup)

    def setup_handlers(self):
        """إعداد handlers مبسطة"""
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(MessageHandler(filters.CONTACT, self.handle_contact))
        self.application.add_handler(CallbackQueryHandler(self.button_handler))

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة الأزرار"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        if data in ["buy", "sell"]:
            await query.edit_message_text(f"🔧 هذه الميزة قيد التطوير: {data}")
        elif data == "balance":
            user = self.db.get_user(update.effective_user.id)
            await query.edit_message_text(f"💼 رصيدك: {user.balance_usdt if user else 0} USDT")

    def run(self):
        """تشغيل البوت"""
        self.application = Application.builder().token(self.config.BOT_TOKEN).build()
        self.setup_handlers()
        
        logging.info("🚀 بدء تشغيل البوت المبسط...")
        self.application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    bot = SimpleUSDTBot()
    bot.run()