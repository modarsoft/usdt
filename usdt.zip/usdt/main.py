import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from database import DatabaseManager, User, Offer, Trade, CommissionSetting, AdminMessage
from config import Config
from admin_panel import AdminPanel
import asyncio
import random
import string
from datetime import datetime

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class USDTradingBot:
    def __init__(self):
        self.config = Config()
        self.db = DatabaseManager(self.config.DATABASE_URL)
        self.admin_panel = AdminPanel(self.db, self.config, self)
        self.application = None
        self.user_states = {}
        self.channel_offer_messages = {}  # لتخزين معرفات رسائل العروض في القناة

    async def is_user_member(self, user_id):
        """التحقق إذا كان المستخدم منضم للقناة"""
        try:
            if not self.config.has_channel or not self.config.FORCE_CHANNEL_JOIN:
                return True
                
            chat_member = await self.application.bot.get_chat_member(
                f"@{self.config.CHANNEL_USERNAME}", 
                user_id
            )
            return chat_member.status in ['member', 'administrator', 'creator']
        except Exception as e:
            logging.error(f"❌ خطأ في التحقق من العضوية: {e}")
            return False

    async def post_offer_to_channel(self, offer):
        """نشر العرض في القناة"""
        try:
            if not self.config.has_channel or not self.config.POST_OFFERS_TO_CHANNEL:
                logging.info("ℹ️ نشر العروض في القناة معطل")
                return None
            
            user = self.db.get_user(offer.user_id)
            username = user.username if user and user.username else "مستخدم"
            offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
            payment_name = self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)
            
            status_icon = "✅" if not offer.is_crossed else "❌"
            status_text = "نشط" if not offer.is_crossed else "معطل"
            
            message = (
                f"🆕 **عرض {offer_type_ar} {status_icon}**\n\n"
                f"🆔 **رقم العرض:** `{offer.offer_id}`\n"
                f"👤 **المستخدم:** @{username}\n"
                f"💵 **الكمية:** {offer.amount_usdt} USDT\n"
                f"💰 **السعر:** {offer.price_per_usdt} لكل USDT\n"
                f"💲 **الإجمالي:** {offer.total_amount:.2f}\n"
                f"💳 **طريقة الدفع:** {payment_name}\n"
                f"📊 **الحالة:** {status_text}\n\n"
                f"📅 **تاريخ الإنشاء:** {offer.created_at.strftime('%Y-%m-%d %H:%M')}\n\n"
                f"🔗 **للتداول:** @{self.application.bot.username}"
            )
            
            keyboard = [
                [InlineKeyboardButton(
                    f"🛒 {'اشتري الآن' if offer.offer_type == 'sell' else 'بع الآن'}",
                    url=f"https://t.me/{self.application.bot.username}?start=offer_{offer.offer_id}"
                )]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # إرسال الرسالة إلى القناة
            sent_message = await self.application.bot.send_message(
                chat_id=f"@{self.config.CHANNEL_USERNAME}",
                text=message,
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
            # حفظ معرف الرسالة للعرض
            self.channel_offer_messages[offer.offer_id] = sent_message.message_id
            
            logging.info(f"✅ تم نشر العرض {offer.offer_id} في القناة @{self.config.CHANNEL_USERNAME}")
            return sent_message.message_id
            
        except Exception as e:
            logging.error(f"❌ خطأ في نشر العرض في القناة: {e}")
            return None

    async def update_offer_in_channel(self, offer):
        """تحديث العرض في القناة"""
        try:
            if not self.config.has_channel or not self.config.POST_OFFERS_TO_CHANNEL:
                return
            
            message_id = self.channel_offer_messages.get(offer.offer_id)
            if not message_id:
                logging.warning(f"⚠️ لم يتم العثور على معرف رسالة العرض {offer.offer_id} في القناة")
                return
            
            user = self.db.get_user(offer.user_id)
            username = user.username if user and user.username else "مستخدم"
            offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
            payment_name = self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)
            
            status_icon = "✅" if not offer.is_crossed else "❌"
            status_text = "نشط" if not offer.is_crossed else "معطل"
            
            message = (
                f"🆕 **عرض {offer_type_ar} {status_icon}**\n\n"
                f"🆔 **رقم العرض:** `{offer.offer_id}`\n"
                f"👤 **المستخدم:** @{username}\n"
                f"💵 **الكمية:** {offer.amount_usdt} USDT\n"
                f"💰 **السعر:** {offer.price_per_usdt} لكل USDT\n"
                f"💲 **الإجمالي:** {offer.total_amount:.2f}\n"
                f"💳 **طريقة الدفع:** {payment_name}\n"
                f"📊 **الحالة:** {status_text}\n\n"
                f"📅 **تاريخ الإنشاء:** {offer.created_at.strftime('%Y-%m-%d %H:%M')}\n\n"
                f"🔗 **للتداول:** @{self.application.bot.username}"
            )
            
            keyboard = [
                [InlineKeyboardButton(
                    f"🛒 {'اشتري الآن' if offer.offer_type == 'sell' else 'بع الآن'}",
                    url=f"https://t.me/{self.application.bot.username}?start=offer_{offer.offer_id}"
                )]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # تحديث الرسالة في القناة
            await self.application.bot.edit_message_text(
                chat_id=f"@{self.config.CHANNEL_USERNAME}",
                message_id=message_id,
                text=message,
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
            logging.info(f"✅ تم تحديث العرض {offer.offer_id} في القناة")
            
        except Exception as e:
            logging.error(f"❌ خطأ في تحديث العرض في القناة: {e}")

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """بدء البوت"""
        try:
            user = update.effective_user
            logging.info(f"🔹 بدء جلسة للمستخدم: {user.id}")
            
            # التحقق من وجود معرّف عرض في الرسالة
            offer_id = None
            if context.args and context.args[0].startswith('offer_'):
                offer_id = context.args[0].replace('offer_', '')
            
            # التحقق الإجباري من انضمام القناة
            if self.config.FORCE_CHANNEL_JOIN and self.config.has_channel:
                is_member = await self.is_user_member(user.id)
                
                if not is_member:
                    await self.request_channel_join(update, context)
                    return
            
            db_user = self.db.get_user(user.id)
            
            if not db_user:
                user_data = {
                    'telegram_id': str(user.id),
                    'username': user.username,
                    'first_name': user.first_name,
                    'last_name': user.last_name
                }
                db_user = self.db.create_user(user_data)
                logging.info(f"✅ تم إنشاء مستخدم جديد: {user.id}")
            
            await self.show_welcome(update, context)
            
            # إذا كان هناك معرّف عرض، عرض تفاصيله
            if offer_id:
                await self.view_offer_direct(update, context, offer_id)
            else:
                await self.show_main_menu(update, context)
            
        except Exception as e:
            logging.error(f"❌ خطأ في الأمر start: {e}")
            await update.message.reply_text("🎉 مرحباً بك! استخدم /menu للقائمة الرئيسية")

    async def request_channel_join(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """طلب الانضمام للقناة"""
        try:
            keyboard = [
                [InlineKeyboardButton("📢 انضم للقناة", url=self.config.CHANNEL_URL)],
                [InlineKeyboardButton("✅ تحقق من الانضمام", callback_data="check_membership")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            message = (
                "🎯 **مرحباً بك في بوت تداول USDT!**\n\n"
                "لتتمكن من استخدام البوت، يجب الانضمام إلى قناتنا أولاً:\n\n"
                f"📢 **@{self.config.CHANNEL_USERNAME}**\n\n"
                "✅ بعد الانضمام، اضغط على زر 'تحقق من الانضمام'"
            )
            
            if update.message:
                await update.message.reply_text(message, reply_markup=reply_markup)
            elif update.callback_query:
                await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في طلب الانضمام للقناة: {e}")

    async def check_membership(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """التحقق من انضمام المستخدم للقناة"""
        try:
            query = update.callback_query
            await query.answer()
            
            user_id = update.effective_user.id
            is_member = await self.is_user_member(user_id)
            
            if is_member:
                await query.edit_message_text(
                    "🎉 **تم التحقق بنجاح!**\n\n"
                    "✅ الآن يمكنك استخدام جميع ميزات البوت"
                )
                
                await asyncio.sleep(1)
                await self.show_main_menu(update, context)
            else:
                keyboard = [
                    [InlineKeyboardButton("📢 انضم للقناة", url=self.config.CHANNEL_URL)],
                    [InlineKeyboardButton("🔄 تحقق مرة أخرى", callback_data="check_membership")]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(
                    "❌ **لم يتم العثور على انضمامك للقناة بعد**\n\n"
                    "⚠️ يرجى:\n"
                    "1. الانضمام للقناة أولاً\n"
                    "2. ثم الضغط على 'تحقق مرة أخرى'\n\n"
                    f"**القناة:** @{self.config.CHANNEL_USERNAME}",
                    reply_markup=reply_markup
                )
                
        except Exception as e:
            logging.error(f"❌ خطأ في التحقق من العضوية: {e}")
            await query.answer("❌ حدث خطأ في التحقق")

    async def require_channel_membership(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """التحقق من العضوية قبل تنفيذ أي أمر"""
        if not self.config.FORCE_CHANNEL_JOIN or not self.config.has_channel:
            return True
            
        user_id = update.effective_user.id
        is_member = await self.is_user_member(user_id)
        
        if not is_member:
            await self.request_channel_join(update, context)
            return False
            
        return True

    async def show_welcome(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض رسالة ترحيب"""
        welcome_message = self.db.get_admin_message('welcome')
        welcome_text = welcome_message.content_ar if welcome_message else (
            "🎉 **مرحباً بك في بوت تداول USDT!**\n\n"
            "منصة آمنة وسهلة لشراء وبيع USDT\n"
            "اختر من القائمة أدناه لبدء التداول"
        )
        
        if update.message:
            await update.message.reply_text(welcome_text)
        elif update.callback_query:
            await update.callback_query.message.reply_text(welcome_text)

    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض القائمة الرئيسية"""
        try:
            # التحقق من العضوية أولاً
            if not await self.require_channel_membership(update, context):
                return
                
            keyboard = [
                [InlineKeyboardButton("🛒 شراء USDT", callback_data="show_buy_offers")],
                [InlineKeyboardButton("💰 بيع USDT", callback_data="show_sell_offers")],
                [InlineKeyboardButton("➕ إنشاء عرض", callback_data="create_offer")],
                [InlineKeyboardButton("👛 رصيدي", callback_data="show_balance")],
                [InlineKeyboardButton("📊 عروضي", callback_data="my_offers")],
                [InlineKeyboardButton("ℹ️ المساعدة", callback_data="help")]
            ]
            
            if update.effective_user.id in self.config.ADMIN_IDS:
                keyboard.append([InlineKeyboardButton("🛠️ لوحة التحكم", callback_data="admin_dashboard")])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            message_text = "🏠 **القائمة الرئيسية**\n\nاختر الخيار المناسب:"
            
            if update.message:
                await update.message.reply_text(message_text, reply_markup=reply_markup)
            elif update.callback_query:
                await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
                
        except Exception as e:
            logging.error(f"❌ خطأ في عرض القائمة: {e}")
            await self.send_error_response(update, context, "عرض القائمة")

    async def show_balance(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض الرصيد"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            user = self.db.get_user(update.effective_user.id)
            
            if not user:
                await self.send_error_response(update, context, "العثور على المستخدم")
                return
            
            message = (
                "👛 **رصيدك الحالي**\n\n"
                f"💵 USDT: {user.balance_usdt:.2f}\n"
                f"💲 نقدي: {user.balance_fiat:.2f}\n\n"
                f"📊 عدد الصفقات: {user.total_trades}\n"
                f"⭐ التقييم: {user.rating}/5.0"
            )
            
            keyboard = [[InlineKeyboardButton("🔙 رجوع للقائمة", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            if update.callback_query:
                await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
            elif update.message:
                await update.message.reply_text(message, reply_markup=reply_markup)
                
        except Exception as e:
            logging.error(f"❌ خطأ في عرض الرصيد: {e}")
            await self.send_error_response(update, context, "عرض الرصيد")

    async def show_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض المساعدة"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            help_message = self.db.get_admin_message('help')
            if help_message:
                message = help_message.content_ar
            else:
                message = (
                    "ℹ️ **مركز المساعدة**\n\n"
                    "🛒 **لشراء USDT:**\n"
                    "1. اختر 'عروض الشراء'\n"
                    "2. اختر العرض المناسب\n"
                    "3. تواصل مع البائع\n\n"
                    "💰 **لبيع USDT:**\n"
                    "1. اختر 'عروض البيع'\n"
                    "2. اختر العرض المناسب\n"
                    "3. تواصل مع المشتري\n\n"
                    "➕ **لإنشاء عرض:**\n"
                    "1. اختر 'إنشاء عرض'\n"
                    "2. اختر النوع (شراء/بيع)\n"
                    "3. اتبع التعليمات\n\n"
                    "💬 للأسئلة والدعم: @your_support"
                )
            
            keyboard = [[InlineKeyboardButton("🔙 رجوع للقائمة", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            if update.callback_query:
                await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
            elif update.message:
                await update.message.reply_text(message, reply_markup=reply_markup)
                
        except Exception as e:
            logging.error(f"❌ خطأ في عرض المساعدة: {e}")
            await self.send_error_response(update, context, "عرض المساعدة")

    async def show_buy_offers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض عروض الشراء"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            offers = self.db.get_active_offers(offer_type='sell')
            
            if not offers:
                await query.edit_message_text(
                    "📭 **لا توجد عروض بيع حالياً**\n\n"
                    "يمكنك إنشاء عرض شراء أو العودة لاحقاً",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("➕ إنشاء عرض شراء", callback_data="create_buy_offer")],
                        [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]
                    ])
                )
                return
            
            message = "🛒 **عروض البيع المتاحة:**\n\n"
            keyboard = []
            
            for offer in offers[:10]:
                user = self.db.get_user(offer.user_id)
                username = user.username if user else "مستخدم"
                crossed_icon = "❌" if offer.is_crossed else "✅"
                status_text = "معطل" if offer.is_crossed else "نشط"
                
                message += (
                    f"{crossed_icon} **العرض:** {offer.offer_id}\n"
                    f"👤 **البائع:** {username}\n"
                    f"💵 **المبلغ:** {offer.amount_usdt} USDT\n"
                    f"💰 **السعر:** {offer.price_per_usdt} لكل USDT\n"
                    f"💳 **الدفع:** {self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)}\n"
                    f"📊 **الحالة:** {status_text}\n"
                    f"────────────────────\n"
                )
                
                if not offer.is_crossed:
                    keyboard.append([
                        InlineKeyboardButton(
                            f"🛒 شراء من {offer.offer_id}",
                            callback_data=f"view_offer_{offer.offer_id}"
                        )
                    ])
            
            keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في عرض عروض الشراء: {e}")
            await self.send_error_response(update, context, "عرض عروض الشراء")

    async def show_sell_offers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض عروض البيع"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            offers = self.db.get_active_offers(offer_type='buy')
            
            if not offers:
                await query.edit_message_text(
                    "📭 **لا توجد عروض شراء حالياً**\n\n"
                    "يمكنك إنشاء عرض بيع أو العودة لاحقاً",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("➕ إنشاء عرض بيع", callback_data="create_sell_offer")],
                        [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]
                    ])
                )
                return
            
            message = "💰 **عروض الشراء المتاحة:**\n\n"
            keyboard = []
            
            for offer in offers[:10]:
                user = self.db.get_user(offer.user_id)
                username = user.username if user else "مستخدم"
                crossed_icon = "❌" if offer.is_crossed else "✅"
                status_text = "معطل" if offer.is_crossed else "نشط"
                
                message += (
                    f"{crossed_icon} **العرض:** {offer.offer_id}\n"
                    f"👤 **المشتري:** {username}\n"
                    f"💵 **المبلغ:** {offer.amount_usdt} USDT\n"
                    f"💰 **السعر:** {offer.price_per_usdt} لكل USDT\n"
                    f"💳 **الدفع:** {self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)}\n"
                    f"📊 **الحالة:** {status_text}\n"
                    f"────────────────────\n"
                )
                
                if not offer.is_crossed:
                    keyboard.append([
                        InlineKeyboardButton(
                            f"💰 بيع لـ {offer.offer_id}",
                            callback_data=f"view_offer_{offer.offer_id}"
                        )
                    ])
            
            keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في عرض عروض البيع: {e}")
            await self.send_error_response(update, context, "عرض عروض البيع")

    async def create_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """بدء إنشاء عرض"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            keyboard = [
                [InlineKeyboardButton("🛒 عرض شراء", callback_data="create_buy_offer")],
                [InlineKeyboardButton("💰 عرض بيع", callback_data="create_sell_offer")],
                [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "➕ **إنشاء عرض جديد**\n\n"
                "اختر نوع العرض الذي تريد إنشاءه:",
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logging.error(f"❌ خطأ في إنشاء العرض: {e}")
            await self.send_error_response(update, context, "إنشاء العرض")

    async def create_buy_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إنشاء عرض شراء"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            self.user_states[update.effective_user.id] = {
                'state': 'awaiting_buy_amount',
                'offer_type': 'buy'
            }
            
            keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🛒 **إنشاء عرض شراء**\n\n"
                "📝 الرجاء إدخال كمية USDT التي تريد شراءها:\n\n"
                "مثال: 100",
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logging.error(f"❌ خطأ في إنشاء عرض شراء: {e}")
            await self.send_error_response(update, context, "إنشاء عرض شراء")

    async def create_sell_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إنشاء عرض بيع"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            self.user_states[update.effective_user.id] = {
                'state': 'awaiting_sell_amount',
                'offer_type': 'sell'
            }
            
            keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "💰 **إنشاء عرض بيع**\n\n"
                "📝 الرجاء إدخال كمية USDT التي تريد بيعها:\n\n"
                "مثال: 100",
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logging.error(f"❌ خطأ في إنشاء عرض بيع: {e}")
            await self.send_error_response(update, context, "إنشاء عرض بيع")

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة الرسائل النصية"""
        try:
            user_id = update.effective_user.id
            
            # التحقق من العضوية أولاً
            if not await self.require_channel_membership(update, context):
                return
                
            text = update.message.text
            
            if user_id not in self.user_states:
                return
            
            state_data = self.user_states[user_id]
            state = state_data['state']
            
            if state == 'awaiting_buy_amount':
                await self.handle_buy_amount(update, context, text, state_data)
            elif state == 'awaiting_sell_amount':
                await self.handle_sell_amount(update, context, text, state_data)
            elif state == 'awaiting_price':
                await self.handle_price(update, context, text, state_data)
                
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة الرسالة: {e}")
            await update.message.reply_text("❌ حدث خطأ في المعالجة")

    async def handle_buy_amount(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, state_data: dict):
        """معالجة كمية الشراء"""
        try:
            amount = float(text)
            if amount <= 0:
                await update.message.reply_text("❌ الرجاء إدخال مبلغ صحيح أكبر من الصفر")
                return
            
            state_data['amount_usdt'] = amount
            state_data['state'] = 'awaiting_price'
            
            keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                f"💵 **كمية USDT:** {amount}\n\n"
                "💰 الرجاء إدخال السعر لكل USDT:\n\n"
                "مثال: 3.75",
                reply_markup=reply_markup
            )
            
        except ValueError:
            await update.message.reply_text("❌ الرجاء إدخال رقم صحيح")

    async def handle_sell_amount(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, state_data: dict):
        """معالجة كمية البيع"""
        try:
            amount = float(text)
            if amount <= 0:
                await update.message.reply_text("❌ الرجاء إدخال مبلغ صحيح أكبر من الصفر")
                return
            
            state_data['amount_usdt'] = amount
            state_data['state'] = 'awaiting_price'
            
            keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                f"💵 **كمية USDT:** {amount}\n\n"
                "💰 الرجاء إدخال السعر لكل USDT:\n\n"
                "مثال: 3.75",
                reply_markup=reply_markup
            )
            
        except ValueError:
            await update.message.reply_text("❌ الرجاء إدخال رقم صحيح")

    async def handle_price(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, state_data: dict):
        """معالجة السعر"""
        try:
            price = float(text)
            if price <= 0:
                await update.message.reply_text("❌ الرجاء إدخال سعر صحيح أكبر من الصفر")
                return
            
            state_data['price_per_usdt'] = price
            state_data['state'] = 'awaiting_payment_method'
            
            # إنشاء أزرار طرق الدفع
            keyboard = []
            payment_methods = list(self.config.PAYMENT_METHODS.items())
            
            for i in range(0, len(payment_methods), 2):
                row = []
                for j in range(2):
                    if i + j < len(payment_methods):
                        method_key, method_name = payment_methods[i + j]
                        row.append(InlineKeyboardButton(method_name, callback_data=f"payment_{method_key}"))
                keyboard.append(row)
            
            keyboard.append([InlineKeyboardButton("🔙 إلغاء", callback_data="main_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            total_amount = state_data['amount_usdt'] * price
            
            await update.message.reply_text(
                f"💰 **السعر:** {price} لكل USDT\n"
                f"💵 **المبلغ الإجمالي:** {total_amount:.2f}\n\n"
                "💳 اختر طريقة الدفع:",
                reply_markup=reply_markup
            )
            
        except ValueError:
            await update.message.reply_text("❌ الرجاء إدخال سعر صحيح")

    async def handle_payment_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة اختيار طريقة الدفع"""
        try:
            query = update.callback_query
            await query.answer()
            
            user_id = update.effective_user.id
            if user_id not in self.user_states:
                await query.edit_message_text("❌ انتهت الجلسة، الرجاء البدء من جديد")
                return
            
            state_data = self.user_states[user_id]
            payment_method = query.data.replace('payment_', '')
            
            if payment_method not in self.config.PAYMENT_METHODS:
                await query.answer("❌ طريقة دفع غير صالحة")
                return
            
            state_data['payment_method'] = payment_method
            
            # إنشاء العرض
            offer_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            total_amount = state_data['amount_usdt'] * state_data['price_per_usdt']
            
            offer_data = {
                'offer_id': offer_id,
                'user_id': user_id,
                'offer_type': state_data['offer_type'],
                'amount_usdt': state_data['amount_usdt'],
                'price_per_usdt': state_data['price_per_usdt'],
                'total_amount': total_amount,
                'payment_method': payment_method,
                'description': f"عرض {state_data['offer_type']} لـ {state_data['amount_usdt']} USDT"
            }
            
            offer = self.db.create_offer(offer_data)
            
            # نشر العرض في القناة
            if offer:
                await self.post_offer_to_channel(offer)
            
            # تنظيف حالة المستخدم
            del self.user_states[user_id]
            
            offer_type_ar = "شراء" if state_data['offer_type'] == 'buy' else "بيع"
            payment_name = self.config.PAYMENT_METHODS[payment_method]
            
            message = (
                f"✅ **تم إنشاء العرض بنجاح!**\n\n"
                f"📋 **تفاصيل العرض:**\n"
                f"🆔 **رقم العرض:** {offer_id}\n"
                f"📊 **النوع:** {offer_type_ar}\n"
                f"💵 **الكمية:** {state_data['amount_usdt']} USDT\n"
                f"💰 **السعر:** {state_data['price_per_usdt']} لكل USDT\n"
                f"💲 **الإجمالي:** {total_amount:.2f}\n"
                f"💳 **طريقة الدفع:** {payment_name}\n\n"
            )
            
            if self.config.has_channel and self.config.POST_OFFERS_TO_CHANNEL:
                message += f"📢 **تم نشر العرض في القناة:** @{self.config.CHANNEL_USERNAME}\n\n"
            
            message += "📢 سيظهر عرضك في قائمة العروض للمستخدمين الآخرين"
            
            keyboard = [
                [InlineKeyboardButton("📊 عرض عروضي", callback_data="my_offers")],
                [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة اختيار الدفع: {e}")
            await query.answer("❌ حدث خطأ في إنشاء العرض")

    async def my_offers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض عروض المستخدم"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            user_id = update.effective_user.id
            offers = self.db.get_user_offers(user_id)
            
            if not offers:
                await query.edit_message_text(
                    "📭 **لا توجد عروض حالياً**\n\n"
                    "يمكنك إنشاء عرض جديد من القائمة الرئيسية",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("➕ إنشاء عرض", callback_data="create_offer")],
                        [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]
                    ])
                )
                return
            
            message = "📊 **عروضي:**\n\n"
            keyboard = []
            
            for offer in offers[:10]:
                status_icon = "🟢" if offer.status == 'active' else "🔴"
                crossed_icon = "❌" if offer.is_crossed else "✅"
                offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
                status_text = "معطل" if offer.is_crossed else "نشط"
                
                message += (
                    f"{status_icon} {crossed_icon} **{offer.offer_id}**\n"
                    f"📊 **النوع:** {offer_type_ar}\n"
                    f"💵 **الكمية:** {offer.amount_usdt} USDT\n"
                    f"💰 **السعر:** {offer.price_per_usdt}\n"
                    f"📊 **الحالة:** {status_text}\n"
                    f"📅 **التاريخ:** {offer.created_at.strftime('%Y-%m-%d %H:%M')}\n"
                    f"────────────────────\n"
                )
                
                keyboard.append([
                    InlineKeyboardButton(
                        f"{'تفعيل ✅' if offer.is_crossed else 'تعطيل ❌'} {offer.offer_id}",
                        callback_data=f"toggle_my_offer_{offer.offer_id}"
                    )
                ])
            
            keyboard.append([InlineKeyboardButton("➕ إنشاء عرض جديد", callback_data="create_offer")])
            keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في عرض عروضي: {e}")
            await self.send_error_response(update, context, "عرض العروض")

    async def toggle_my_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE, offer_id: str):
        """تبديل حالة العرض للمستخدم"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            user_id = update.effective_user.id
            offer = self.db.toggle_offer_crossed(offer_id)
            
            if offer and offer.user_id == str(user_id):
                status = "معطل" if offer.is_crossed else "مفعل"
                await query.answer(f"✅ تم {status} العرض {offer_id}")
                
                # تحديث العرض في القناة
                if self.config.POST_OFFERS_TO_CHANNEL:
                    await self.update_offer_in_channel(offer)
                    
                await self.my_offers(update, context)
            else:
                await query.answer("❌ لم يتم العثور على العرض أو ليس لديك صلاحية")
            
        except Exception as e:
            logging.error(f"❌ خطأ في تبديل حالة العرض: {e}")
            await query.answer("❌ حدث خطأ")

    async def view_offer_direct(self, update: Update, context: ContextTypes.DEFAULT_TYPE, offer_id: str):
        """عرض تفاصيل العرض مباشرة من الرابط"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            offer = self.db.session.query(Offer).filter_by(offer_id=offer_id).first()
            
            if not offer:
                await update.message.reply_text("❌ لم يتم العثور على العرض")
                return
            
            user = self.db.get_user(offer.user_id)
            offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
            action_type = "البيع" if offer.offer_type == 'sell' else "الشراء"
            username = user.username if user else "مستخدم"
            payment_name = self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)
            status_text = "معطل" if offer.is_crossed else "نشط"
            status_icon = "❌" if offer.is_crossed else "✅"
            
            message = (
                f"📋 **تفاصيل العرض {offer_id}**\n\n"
                f"👤 **{action_type} من/إلى:** @{username}\n"
                f"📊 **نوع العرض:** {offer_type_ar}\n"
                f"💵 **كمية USDT:** {offer.amount_usdt}\n"
                f"💰 **السعر لكل USDT:** {offer.price_per_usdt}\n"
                f"💲 **المبلغ الإجمالي:** {offer.total_amount:.2f}\n"
                f"💳 **طريقة الدفع:** {payment_name}\n"
                f"📊 **الحالة:** {status_icon} {status_text}\n\n"
                f"💬 **للتواصل مع {action_type}:**\n"
                f"يمكنك مراسلة المستخدم مباشرة للتفاوض على الصفقة"
            )
            
            keyboard = [
                [InlineKeyboardButton("🛒 عروض الشراء", callback_data="show_buy_offers")],
                [InlineKeyboardButton("💰 عروض البيع", callback_data="show_sell_offers")],
                [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في عرض التفاصيل المباشرة: {e}")
            await update.message.reply_text("❌ حدث خطأ في عرض تفاصيل العرض")

    async def view_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE, offer_id: str):
        """عرض تفاصيل العرض"""
        try:
            if not await self.require_channel_membership(update, context):
                return
                
            query = update.callback_query
            await query.answer()
            
            offer = self.db.session.query(Offer).filter_by(offer_id=offer_id).first()
            
            if not offer:
                await query.edit_message_text("❌ لم يتم العثور على العرض")
                return
            
            user = self.db.get_user(offer.user_id)
            offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
            action_type = "البيع" if offer.offer_type == 'sell' else "الشراء"
            username = user.username if user else "مستخدم"
            payment_name = self.config.PAYMENT_METHODS.get(offer.payment_method, offer.payment_method)
            status_text = "معطل" if offer.is_crossed else "نشط"
            status_icon = "❌" if offer.is_crossed else "✅"
            
            message = (
                f"📋 **تفاصيل العرض {offer_id}**\n\n"
                f"👤 **{action_type} من/إلى:** @{username}\n"
                f"📊 **نوع العرض:** {offer_type_ar}\n"
                f"💵 **كمية USDT:** {offer.amount_usdt}\n"
                f"💰 **السعر لكل USDT:** {offer.price_per_usdt}\n"
                f"💲 **المبلغ الإجمالي:** {offer.total_amount:.2f}\n"
                f"💳 **طريقة الدفع:** {payment_name}\n"
                f"📊 **الحالة:** {status_icon} {status_text}\n\n"
                f"💬 **للتواصل مع {action_type}:**\n"
                f"يمكنك مراسلة المستخدم مباشرة للتفاوض على الصفقة"
            )
            
            offer_type_key = "buy" if offer.offer_type == 'sell' else "sell"
            keyboard = [
                [InlineKeyboardButton("🔄 العودة للعروض", callback_data=f"show_{offer_type_key}_offers")],
                [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(message, reply_markup=reply_markup)
            
        except Exception as e:
            logging.error(f"❌ خطأ في عرض التفاصيل: {e}")
            await query.answer("❌ حدث خطأ في عرض التفاصيل")

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة الأزرار"""
        try:
            query = update.callback_query
            await query.answer()
            
            data = query.data
            logging.info(f"🔹 معالجة زر: {data}")
            
            if data == "check_membership":
                await self.check_membership(update, context)
            elif data == "main_menu":
                await self.show_main_menu(update, context)
            elif data == "show_balance":
                await self.show_balance(update, context)
            elif data == "help":
                await self.show_help(update, context)
            elif data == "admin_dashboard":
                await self.admin_panel.admin_dashboard(update, context)
            elif data == "show_buy_offers":
                await self.show_buy_offers(update, context)
            elif data == "show_sell_offers":
                await self.show_sell_offers(update, context)
            elif data == "create_offer":
                await self.create_offer(update, context)
            elif data == "create_buy_offer":
                await self.create_buy_offer(update, context)
            elif data == "create_sell_offer":
                await self.create_sell_offer(update, context)
            elif data == "my_offers":
                await self.my_offers(update, context)
            elif data.startswith("payment_"):
                await self.handle_payment_selection(update, context)
            elif data.startswith("toggle_my_offer_"):
                offer_id = data.replace("toggle_my_offer_", "")
                await self.toggle_my_offer(update, context, offer_id)
            elif data.startswith("view_offer_"):
                offer_id = data.replace("view_offer_", "")
                await self.view_offer(update, context, offer_id)
            else:
                await query.edit_message_text("⚠️ الأمر غير معروف")
                
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة الزر: {e}")
            await query.answer("❌ حدث خطأ")

    async def send_error_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE, action: str):
        """إرسال رسالة خطأ"""
        error_message = f"⚠️ عذراً، حدث خطأ في {action}\nالرجاء المحاولة مرة أخرى"
        
        if update.message:
            await update.message.reply_text(error_message)
        elif update.callback_query:
            await update.callback_query.message.reply_text(error_message)

    def setup_handlers(self):
        """إعداد جميع ال handlers"""
        if not self.application:
            logging.error("❌ تطبيق البوت غير مهيء")
            return

        # ال handlers الأساسية
        handlers = [
            CommandHandler("start", self.start),
            CommandHandler("menu", self.show_main_menu),
            CommandHandler("balance", self.show_balance),
            CommandHandler("help", self.show_help),
            CommandHandler("admin", self.admin_panel.admin_dashboard),
        ]
        
        for handler in handlers:
            self.application.add_handler(handler)
        
        # handler للأزرار العادية
        self.application.add_handler(CallbackQueryHandler(self.button_handler))
        
        # handler خاص للأدمن - تأكد من أن هذا موجود
        self.application.add_handler(CallbackQueryHandler(
            self.admin_panel.handle_admin_callback,
            pattern="^admin_"
        ))
        
        # handler للرسائل النصية العادية
        self.application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.handle_message
        ))
        
        # handler لرسائل الأدمن (لإدخال العمولة والرسائل)
        self.application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.admin_panel.admin_handle_commission_input
        ))
        
        self.application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self.admin_panel.admin_handle_message_input
        ))
        
        logging.info("✅ تم إعداد جميع handlers بنجاح")

    def run_bot(self):
        """تشغيل البوت - تم تغيير الاسم من run إلى run_bot"""
        try:
            logging.info("🚀 بدء تشغيل بوت تداول USDT...")
            
            # إنشاء التطبيق
            self.application = Application.builder().token(self.config.BOT_TOKEN).build()
            
            # إعداد handlers
            self.setup_handlers()
            
            # تشغيل البوت
            logging.info("✅ البوت يعمل الآن...")
            self.application.run_polling()
            
        except Exception as e:
            logging.error(f"❌ خطأ في تشغيل البوت: {e}")
            raise

if __name__ == "__main__":
    bot = USDTradingBot()
    bot.run_bot()  # تم تغيير هذا السطر من run() إلى run_bot()