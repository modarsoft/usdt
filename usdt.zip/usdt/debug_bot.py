import logging
from main import USDTradingBot

# تشغيل مفصل للتسجيل
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

if __name__ == "__main__":
    bot = USDTradingBot()
    bot.run()