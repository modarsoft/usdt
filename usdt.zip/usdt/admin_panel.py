import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

class AdminPanel:
    def __init__(self, db, config, bot_instance):
        self.db = db
        self.config = config
        self.bot = bot_instance
    
    def is_admin(self, user_id):
        """التحقق من صلاحية المشرف"""
        return user_id in self.config.ADMIN_IDS
    
    async def send_message(self, update: Update, text: str, reply_markup=None):
        """إرسال رسالة مع معالجة جميع الحالات"""
        try:
            if update.message:
                await update.message.reply_text(text, reply_markup=reply_markup)
            elif update.callback_query:
                await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
        except Exception as e:
            logging.error(f"❌ خطأ في إرسال الرسالة: {e}")
    
    async def admin_dashboard(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """لوحة تحكم المشرف الرئيسية"""
        user_id = update.effective_user.id
        if not self.is_admin(user_id):
            await self.send_message(update, "❌ ليس لديك صلاحية الوصول لهذا القسم")
            return
        
        # إحصائيات سريعة
        total_users = len(self.db.get_all_users())
        active_offers = len([o for o in self.db.get_all_offers() if o.status == 'active'])
        total_offers = len(self.db.get_all_offers())
        total_trades = len(self.db.get_all_trades())
        
        keyboard = [
            [InlineKeyboardButton("📊 الإحصائيات", callback_data="admin_stats")],
            [InlineKeyboardButton("📋 إدارة العروض", callback_data="admin_offers")],
            [InlineKeyboardButton("👥 إدارة المستخدمين", callback_data="admin_users")],
            [InlineKeyboardButton("⚙️ إعدادات العمولة", callback_data="admin_commission")],
            [InlineKeyboardButton("✉️ إدارة الرسائل", callback_data="admin_messages")],
            [InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        message = (
            "🛠️ **لوحة تحكم المشرف**\n\n"
            f"👥 **إجمالي المستخدمين:** {total_users}\n"
            f"📋 **العروض النشطة:** {active_offers}\n"
            f"📊 **إجمالي العروض:** {total_offers}\n"
            f"💰 **إجمالي الصفقات:** {total_trades}"
        )
        
        await self.send_message(update, message, reply_markup)
    
    async def admin_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إحصائيات مفصلة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        from datetime import datetime
        today = datetime.now().date()
        
        users = self.db.get_all_users()
        offers = self.db.get_all_offers()
        trades = self.db.get_all_trades()
        
        # إحصائيات اليوم
        today_users = len([u for u in users if u.created_at.date() == today])
        today_offers = len([o for o in offers if o.created_at.date() == today])
        
        # إحصائيات العروض
        buy_offers = len([o for o in offers if o.offer_type == 'buy'])
        sell_offers = len([o for o in offers if o.offer_type == 'sell'])
        active_offers = len([o for o in offers if o.status == 'active'])
        crossed_offers = len([o for o in offers if o.is_crossed])
        
        # أفضل المستخدمين حسب عدد الصفقات
        active_users = sorted(users, key=lambda x: x.total_trades, reverse=True)[:5]
        
        stats_message = "📊 **الإحصائيات التفصيلية**\n\n"
        stats_message += "📈 **إحصائيات اليوم:**\n"
        stats_message += f"• المستخدمين الجدد: {today_users}\n"
        stats_message += f"• العروض الجديدة: {today_offers}\n\n"
        
        stats_message += "📋 **إحصائيات العروض:**\n"
        stats_message += f"• عروض الشراء: {buy_offers}\n"
        stats_message += f"• عروض البيع: {sell_offers}\n"
        stats_message += f"• عروض نشطة: {active_offers}\n"
        stats_message += f"• عروض معطلة: {crossed_offers}\n\n"
        
        stats_message += "👥 **إحصائيات المستخدمين:**\n"
        stats_message += f"• إجمالي المستخدمين: {len(users)}\n"
        stats_message += f"• إجمالي الصفقات: {len(trades)}\n\n"
        
        stats_message += "🏆 **أفضل المستخدمين حسب الصفقات:**\n"
        
        for i, user in enumerate(active_users, 1):
            username = user.username or user.first_name or f"المستخدم {user.telegram_id}"
            stats_message += f"{i}. {username} - {user.total_trades} صفقة\n"
        
        keyboard = [
            [InlineKeyboardButton("🔄 تحديث", callback_data="admin_stats")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(stats_message, reply_markup=reply_markup)
    
    async def admin_offers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إدارة العروض"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        offers = self.db.get_all_offers()
        offers.reverse()  # عرض أحدث العروض أولاً
        offers = offers[:15]  # آخر 15 عرض
        
        if not offers:
            await query.edit_message_text("📭 لا توجد عروض حالياً")
            return
        
        message = "📋 **إدارة العروض**\n\n"
        keyboard = []
        
        for offer in offers:
            user = self.db.get_user(offer.user_id)
            status_icon = "🟢" if offer.status == 'active' else "🔴"
            crossed_icon = "❌" if offer.is_crossed else "✅"
            offer_type_ar = "شراء" if offer.offer_type == 'buy' else "بيع"
            username = user.username if user else f"المستخدم {offer.user_id}"
            status_text = "معطل" if offer.is_crossed else "نشط"
            
            message += (
                f"{status_icon} {crossed_icon} **{offer.offer_id}**\n"
                f"👤 {username} | {offer_type_ar}\n"
                f"💵 {offer.amount_usdt} USDT | 💰 {offer.price_per_usdt}\n"
                f"📊 الحالة: {status_text}\n"
                f"📅 {offer.created_at.strftime('%Y-%m-%d %H:%M')}\n"
                f"────────────────────\n"
            )
            
            keyboard.append([
                InlineKeyboardButton(
                    f"{'تفعيل ✅' if offer.is_crossed else 'تعطيل ❌'} {offer.offer_id}",
                    callback_data=f"admin_toggle_{offer.offer_id}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔄 تحديث", callback_data="admin_offers")])
        keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_toggle_offer(self, update: Update, context: ContextTypes.DEFAULT_TYPE, offer_id):
        """تبديل حالة العرض مع تحديث القناة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        offer = self.db.toggle_offer_crossed(offer_id)
        if offer:
            status = "معطل" if offer.is_crossed else "مفعل"
            await query.answer(f"✅ تم {status} العرض {offer_id}")
            
            # تحديث العرض في القناة
            if hasattr(self.bot, 'update_offer_in_channel'):
                await self.bot.update_offer_in_channel(offer)
            
            await self.admin_offers(update, context)
        else:
            await query.answer("❌ لم يتم العثور على العرض")
    
    async def admin_users(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إدارة المستخدمين"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        users = self.db.get_all_users()
        users.reverse()  # عرض أحدث المستخدمين أولاً
        users = users[:10]  # آخر 10 مستخدمين
        
        message = "👥 **إدارة المستخدمين**\n\n"
        
        for user in users:
            user_offers = len(self.db.get_user_offers(user.telegram_id))
            status = "🟢" if not user.is_banned else "🔴"
            username = user.username or user.first_name or f"المستخدم {user.telegram_id}"
            status_text = "محظور" if user.is_banned else "نشط"
            
            message += (
                f"{status} **{username}**\n"
                f"🆔 {user.telegram_id}\n"
                f"📞 {user.phone or 'لا يوجد'}\n"
                f"📊 {user_offers} عرض | ⭐ {user.rating}\n"
                f"📈 {user.total_trades} صفقة | 🚫 {status_text}\n"
                f"📅 {user.created_at.strftime('%Y-%m-%d')}\n"
                f"────────────────────\n"
            )
        
        keyboard = [
            [InlineKeyboardButton("🔄 تحديث", callback_data="admin_users")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_commission(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إعدادات العمولة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        settings = self.db.get_commission_settings()
        
        message = "⚙️ **إعدادات العمولة الحالية:**\n\n"
        for setting in settings:
            type_ar = {
                'buy': '🛒 عمولة الشراء',
                'sell': '💰 عمولة البيع', 
                'both': '📊 عمولة عامة'
            }.get(setting.commission_type, setting.commission_type)
            
            message += f"{type_ar}: {setting.percentage}%\n"
        
        message += "\nاختر نوع العمولة لتعديلها:"
        
        keyboard = [
            [InlineKeyboardButton("🛒 عمولة الشراء", callback_data="admin_set_buy")],
            [InlineKeyboardButton("💰 عمولة البيع", callback_data="admin_set_sell")],
            [InlineKeyboardButton("📊 عمولة عامة", callback_data="admin_set_both")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_set_commission(self, update: Update, context: ContextTypes.DEFAULT_TYPE, commission_type: str):
        """تحديد قيمة العمولة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        # حفظ نوع العمولة في context للاستخدام لاحقاً
        context.user_data['commission_type'] = commission_type
        
        type_ar = {
            'buy': 'الشراء',
            'sell': 'البيع', 
            'both': 'العامة'
        }.get(commission_type, commission_type)
        
        message = f"⚙️ **تعديل عمولة {type_ar}**\n\n"
        message += "الرجاء إرسال النسبة المئوية الجديدة للعمولة:\n"
        message += "مثال: 1.5 (لـ 1.5%)\n\n"
        message += "أو اضغط إلغاء للتراجع"
        
        keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="admin_commission")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_handle_commission_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة إدخال قيمة العمولة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        try:
            user_id = update.effective_user.id
            if not self.is_admin(user_id):
                return
                
            commission_type = context.user_data.get('commission_type')
            if not commission_type:
                await update.message.reply_text("❌ لم يتم تحديد نوع العمولة")
                return
            
            percentage = float(update.message.text)
            if percentage < 0 or percentage > 100:
                await update.message.reply_text("❌ النسبة يجب أن تكون بين 0 و 100")
                return
            
            # تحديث العمولة في قاعدة البيانات
            setting = self.db.update_commission(commission_type, percentage, user_id)
            
            if setting:
                type_ar = {
                    'buy': 'الشراء',
                    'sell': 'البيع', 
                    'both': 'العامة'
                }.get(commission_type, commission_type)
                
                await update.message.reply_text(f"✅ تم تحديث عمولة {type_ar} إلى {percentage}%")
                
                # العودة إلى لوحة العمولة
                from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                keyboard = [[InlineKeyboardButton("🔙 رجوع للوحة التحكم", callback_data="admin_back")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await update.message.reply_text("اختر الإجراء التالي:", reply_markup=reply_markup)
                
            else:
                await update.message.reply_text("❌ فشل في تحديث العمولة")
            
            # تنظيف البيانات المؤقتة
            context.user_data.pop('commission_type', None)
            
        except ValueError:
            await update.message.reply_text("❌ الرجاء إدخال رقم صحيح")
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة العمولة: {e}")
            await update.message.reply_text("❌ حدث خطأ في تحديث العمولة")
    
    async def admin_messages(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """إدارة الرسائل"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        # الحصول على الرسائل الحالية
        welcome_msg = self.db.get_admin_message('welcome')
        help_msg = self.db.get_admin_message('help')
        rules_msg = self.db.get_admin_message('rules')
        
        message = "✉️ **إدارة الرسائل التلقائية**\n\n"
        message += "📝 **الرسائل الحالية:**\n"
        message += f"🎉 رسالة الترحيب: {'✅ معدة' if welcome_msg else '❌ غير معدة'}\n"
        message += f"ℹ️ رسالة المساعدة: {'✅ معدة' if help_msg else '❌ غير معدة'}\n"
        message += f"📋 القوانين: {'✅ معدة' if rules_msg else '❌ غير معدة'}\n\n"
        message += "اختر الرسالة التي تريد تعديلها:"
        
        keyboard = [
            [InlineKeyboardButton("🎉 تعديل رسالة الترحيب", callback_data="admin_edit_welcome")],
            [InlineKeyboardButton("ℹ️ تعديل رسالة المساعدة", callback_data="admin_edit_help")],
            [InlineKeyboardButton("📋 تعديل القوانين", callback_data="admin_edit_rules")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_edit_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE, message_type: str):
        """تعديل رسالة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        query = update.callback_query
        await query.answer()
        
        # حفظ نوع الرسالة في context
        context.user_data['edit_message_type'] = message_type
        
        type_ar = {
            'welcome': 'الترحيب',
            'help': 'المساعدة',
            'rules': 'القوانين'
        }.get(message_type, message_type)
        
        # الحصول على الرسالة الحالية
        current_msg = self.db.get_admin_message(message_type)
        
        message = f"📝 **تعديل رسالة {type_ar}**\n\n"
        message += "الرجاء إرسال النص الجديد للرسالة:\n\n"
        
        if current_msg:
            message += f"**النص الحالي:**\n{current_msg.content_ar}\n\n"
        
        message += "يمكنك استخدام Markdown للتنسيق"
        
        keyboard = [[InlineKeyboardButton("🔙 إلغاء", callback_data="admin_messages")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    async def admin_handle_message_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة إدخال الرسالة"""
        if not self.is_admin(update.effective_user.id):
            return
        
        try:
            user_id = update.effective_user.id
            if not self.is_admin(user_id):
                return
                
            message_type = context.user_data.get('edit_message_type')
            if not message_type:
                await update.message.reply_text("❌ لم يتم تحديد نوع الرسالة")
                return
            
            new_content = update.message.text
            
            # تحديث الرسالة في قاعدة البيانات
            message = self.db.update_admin_message(message_type, new_content)
            
            if message:
                type_ar = {
                    'welcome': 'الترحيب',
                    'help': 'المساعدة',
                    'rules': 'القوانين'
                }.get(message_type, message_type)
                
                await update.message.reply_text(f"✅ تم تحديث رسالة {type_ar} بنجاح")
                
                # العودة إلى لوحة الرسائل
                from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                keyboard = [[InlineKeyboardButton("🔙 رجوع للوحة التحكم", callback_data="admin_back")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await update.message.reply_text("اختر الإجراء التالي:", reply_markup=reply_markup)
                
            else:
                await update.message.reply_text("❌ فشل في تحديث الرسالة")
            
            # تنظيف البيانات المؤقتة
            context.user_data.pop('edit_message_type', None)
            
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة الرسالة: {e}")
            await update.message.reply_text("❌ حدث خطأ في تحديث الرسالة")
    
    async def admin_back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """العودة للوحة التحكم"""
        await self.admin_dashboard(update, context)
    
    async def handle_admin_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة استدعاءات الأدمن - الدالة الرئيسية"""
        query = update.callback_query
        data = query.data
        
        logging.info(f"🔹 استدعاء أدمن: {data}")
        
        try:
            if data == "admin_stats":
                await self.admin_stats(update, context)
            elif data == "admin_offers":
                await self.admin_offers(update, context)
            elif data == "admin_users":
                await self.admin_users(update, context)
            elif data == "admin_commission":
                await self.admin_commission(update, context)
            elif data == "admin_messages":
                await self.admin_messages(update, context)
            elif data.startswith("admin_toggle_"):
                offer_id = data.replace("admin_toggle_", "")
                await self.admin_toggle_offer(update, context, offer_id)
            elif data.startswith("admin_set_"):
                commission_type = data.replace("admin_set_", "")
                await self.admin_set_commission(update, context, commission_type)
            elif data.startswith("admin_edit_"):
                message_type = data.replace("admin_edit_", "")
                await self.admin_edit_message(update, context, message_type)
            elif data == "admin_back":
                await self.admin_back(update, context)
            else:
                await query.answer("❌ أمر غير معروف")
                
        except Exception as e:
            logging.error(f"❌ خطأ في معالجة استدعاء الأدمن {data}: {e}")
            await query.answer("❌ حدث خطأ في المعالجة")