               payment_method=offer_data['payment_method'],
                description=offer_data.get('description', ''),
                commission=offer_data.get('commission', 0.0)
            )
            self.session.add(offer)
            self.session.commit()
            logging.info(f"✅ تم إنشاء عرض جديد: {offer_data['offer_id']}")
            return offer
        except Exception as e:
            self.session.rollback()
            logging.error(f"❌ خطأ في إنشاء العرض: {e}")
            return None
    
    def get_active_offers(self, offer_type=None, payment_method=None):
        """الحصول على العروض النشطة"""
        try:
            query = self.session.query(Offer).filter_by(status='active')
            
            if offer_type:
                query = query.filter_by(offer_type=offer_type)
            if payment_method:
                que