ault=datetime.utcnow)

class Transaction(Base):
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    transaction_id = Column(String(50), unique=True, nullable=False)
    user_id = Column(String(50), nullable=False)
    type = Column(String(20), nullable=False)  # deposit, withdrawal, trade
    amount = Column(Float, nullable=False)
    currency = Column(String(10), nullable=False)  # USDT, fiat
    status = Column(String(20), default='pending')  # pending, completed, failed
    details = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

class DatabaseManager:
    def __init__(self, database_url):
        self.engine = create_engine(database_url)
        self.create_tables()
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
        self.initialize_default_data()
    
    def create_tables(self):
        """إنشاء الجداول في قاعدة البيانات"""
 