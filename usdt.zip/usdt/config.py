import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    def __init__(self):
        self.BOT_TOKEN = os.getenv('BOT_TOKEN')
        
        # استخدام SQLite بشكل افتراضي
        self.DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///usdt_trading.db')
        
        # تحويل ADMIN_IDS إلى قائمة
        admin_ids = os.getenv('ADMIN_IDS', '')
        self.ADMIN_IDS = [int(x.strip()) for x in admin_ids.split(',') if x.strip()]
        
        # إعدادات الدفع
        self.PAYMENT_METHODS = {
            'bank_transfer': 'تحويل بنكي',
            'paypal': 'باي بال',
            'wise': 'وايز',
            'binance': 'باينانس',
            'cash': 'كاش',
            'stc_pay': 'STC Pay',
            'mada': 'مدى',
            'vodafone_cash': 'فودافون كاش',
            'etisalat_cash': 'اتصالات كاش'
        }
        
        # إعدادات القناة
        self.CHANNEL_USERNAME = os.getenv('CHANNEL_USERNAME', '').replace('@', '')
        self.CHANNEL_URL = os.getenv('CHANNEL_URL', '')
        
        # إعدادات نشر العروض في القناة
        self.POST_OFFERS_TO_CHANNEL = os.getenv('POST_OFFERS_TO_CHANNEL', 'True').lower() == 'true'
        
        # التحقق الإجباري من القناة
        self.FORCE_CHANNEL_JOIN = os.getenv('FORCE_CHANNEL_JOIN', 'True').lower() == 'true'
    
    @property
    def has_channel(self):
        """التحقق إذا كان هناك قناة محددة"""
        return bool(self.CHANNEL_USERNAME and self.CHANNEL_URL)